#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Controle remoto virtual para o TV box inXplus (Android 7.1) via ADB pela rede.

- Controle desenhado na tela (clique nos botoes)
- Teclado do PC controla o box (setas, Enter, Esc, Home, digitos, ...)
- "Tela" ao lado funciona como mouse: clique = toque, arrastar = deslizar,
  botao direito = Voltar, botao do meio = Home, roda = rolar
- Nao interfere no scrcpy: usa so comandos ADB extras no mesmo servidor ADB.

Requisitos: Python 3 (tkinter ja vem junto no Windows) e o adb.exe
(o da pasta do scrcpy serve; o programa tenta achar sozinho).
"""
import glob
import json
import os
import queue
import re
import shutil
import subprocess
import threading
import time
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

APP_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(APP_DIR, "controle_xplus_config.json")
DEFAULT_IP = ""
LAUNCHER_PKG = "com.xbs.xplus"
PROTECTED_PKGS = {LAUNCHER_PKG, "android", "com.android.systemui"}
NO_WINDOW = getattr(subprocess, "CREATE_NO_WINDOW", 0)

# Codigos de tecla do Android
KEYS = {
    "POWER": 26, "HOME": 3, "BACK": 4, "MENU": 82, "SETTINGS": 176,
    "UP": 19, "DOWN": 20, "LEFT": 21, "RIGHT": 22, "OK": 23, "ENTER": 66,
    "VOL_UP": 24, "VOL_DOWN": 25, "MUTE": 164,
    "PLAY": 85, "REW": 89, "FF": 90, "STOP": 86, "DEL": 67,
}
for _d in range(10):
    KEYS[str(_d)] = 7 + _d

PAD_W = 560  # largura da "tela" que funciona como mouse


# ----------------------------------------------------------------- config
def load_config():
    try:
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}


def save_config(cfg):
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, indent=2)
    except OSError:
        pass


def find_adb(saved=None):
    cands = []
    if saved:
        cands.append(saved)
    cands.append(os.path.join(APP_DIR, "adb.exe"))
    cands += glob.glob(os.path.join(APP_DIR, "scrcpy*", "**", "adb.exe"), recursive=True)
    dl = os.path.join(os.path.expanduser("~"), "Downloads")
    cands += glob.glob(os.path.join(dl, "scrcpy*", "**", "adb.exe"), recursive=True)
    for c in cands:
        if c and os.path.isfile(c):
            return c
    return shutil.which("adb")


# -------------------------------------------------------------------- ADB
class Adb:
    """Executa comandos ADB. As teclas vao por um 'adb shell' persistente
    (resposta rapida, sem abrir um processo novo a cada clique)."""

    def __init__(self, path):
        self.path = path
        self.serial = None
        self.proc = None
        self.lock = threading.Lock()
        self.q = queue.Queue()
        threading.Thread(target=self._worker, daemon=True).start()

    def run(self, args, timeout=10):
        try:
            r = subprocess.run([self.path] + args, capture_output=True, text=True,
                               timeout=timeout, creationflags=NO_WINDOW,
                               encoding="utf-8", errors="replace")
            return r.returncode, (r.stdout or "") + (r.stderr or "")
        except subprocess.TimeoutExpired:
            return 1, "tempo esgotado"
        except OSError as ex:
            return 1, str(ex)

    def open_shell(self):
        with self.lock:
            self._close_locked()
            if not self.serial:
                return
            self.proc = subprocess.Popen(
                [self.path, "-s", self.serial, "shell"],
                stdin=subprocess.PIPE, stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL, creationflags=NO_WINDOW)

    def _close_locked(self):
        if self.proc is not None:
            try:
                self.proc.stdin.close()
            except OSError:
                pass
            try:
                self.proc.terminate()
            except OSError:
                pass
            self.proc = None

    def close(self):
        with self.lock:
            self._close_locked()

    def send(self, cmd):
        self.q.put(cmd)

    def _worker(self):
        while True:
            cmd = self.q.get()
            for _ in range(2):
                try:
                    if self.serial is None:
                        break
                    if self.proc is None or self.proc.poll() is not None:
                        self.open_shell()
                    self.proc.stdin.write((cmd + "\n").encode("utf-8"))
                    self.proc.stdin.flush()
                    break
                except (OSError, ValueError, AttributeError):
                    self.proc = None


# -------------------------------------------------------------------- GUI
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Controle XPLUS (ADB)")
        self.resizable(False, False)
        self.cfg = load_config()
        self.ui_q = queue.Queue()
        self.scr = (1280, 720)
        self._last_key = {}
        self._p0 = None

        path = find_adb(self.cfg.get("adb"))
        if not path:
            messagebox.showinfo("adb nao encontrado",
                                "Escolha o arquivo adb.exe (fica na pasta do scrcpy).")
            path = filedialog.askopenfilename(title="Escolha o adb.exe",
                                              filetypes=[("adb", "adb.exe adb"), ("Todos", "*.*")])
        if not path:
            raise SystemExit("adb nao encontrado")
        self.cfg["adb"] = path
        self.adb = Adb(path)

        self.ip_var = tk.StringVar(value=self.cfg.get("ip", DEFAULT_IP))
        self.status_var = tk.StringVar(value="Desconectado")
        self.log_var = tk.StringVar(value="")
        self.direct_var = tk.BooleanVar(value=False)
        self.text_var = tk.StringVar()

        self._build()
        self.bind_all("<Key>", self.on_key)
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.after(50, self._poll_ui)
        self.after(300, self.do_connect)

    # ---------- utilidades de UI
    def ui(self, fn):
        self.ui_q.put(fn)

    def _poll_ui(self):
        try:
            while True:
                self.ui_q.get_nowait()()
        except queue.Empty:
            pass
        self.after(50, self._poll_ui)

    def log(self, msg):
        self.log_var.set(msg)

    def set_status(self, msg, color):
        self.status_var.set(msg)
        self.status_lbl.config(foreground=color)

    # ---------- construcao
    def _build(self):
        left = ttk.Frame(self, padding=8)
        left.grid(row=0, column=0, sticky="n")
        right = ttk.Frame(self, padding=8)
        right.grid(row=0, column=1, sticky="n")

        self.remote = tk.Canvas(left, width=250, height=680, bg="#f0f0f0", highlightthickness=0)
        self.remote.pack()
        self._draw_remote()

        # conexao
        top = ttk.Frame(right)
        top.pack(fill="x")
        ttk.Label(top, text="IP do box:").pack(side="left")
        ttk.Entry(top, textvariable=self.ip_var, width=22).pack(side="left", padx=4)
        ttk.Button(top, text="Conectar", command=self.do_connect).pack(side="left")
        ttk.Button(top, text="adb...", command=self.pick_adb).pack(side="left", padx=4)
        self.status_lbl = ttk.Label(right, textvariable=self.status_var, foreground="gray")
        self.status_lbl.pack(anchor="w", pady=(4, 6))

        # tela / mouse
        ttk.Label(right, text="Tela do box (use como mouse)").pack(anchor="w")
        self.pad = tk.Canvas(right, width=PAD_W, height=int(PAD_W * 9 / 16), bg="#101418",
                             highlightthickness=1, highlightbackground="#555", cursor="crosshair")
        self.pad.pack()
        self._draw_pad_grid()
        self.pad.bind("<ButtonPress-1>", self.pad_press)
        self.pad.bind("<ButtonRelease-1>", self.pad_release)
        self.pad.bind("<Button-3>", lambda e: self.send_key("BACK"))
        self.pad.bind("<Button-2>", lambda e: self.send_key("HOME"))
        self.pad.bind("<MouseWheel>", self.pad_wheel)
        ttk.Label(right, foreground="gray",
                  text="clique = tocar | arrastar = deslizar | direito = Voltar | meio = Home | roda = rolar"
                  ).pack(anchor="w", pady=(2, 8))

        # ferramentas
        tools = ttk.Frame(right)
        tools.pack(fill="x")
        ttk.Button(tools, text="Abrir scrcpy", command=self.open_scrcpy).pack(side="left")
        ttk.Button(tools, text="Fechar app em foco", command=self.close_focused).pack(side="left", padx=6)
        ttk.Button(tools, text="Reativar launcher", command=self.enable_launcher).pack(side="left")

        # texto
        tf = ttk.LabelFrame(right, text="Digitar texto no box", padding=6)
        tf.pack(fill="x", pady=(10, 0))
        ent = ttk.Entry(tf, textvariable=self.text_var, width=48)
        ent.pack(side="left")
        ent.bind("<Return>", lambda e: self.send_text_box())
        ttk.Button(tf, text="Enviar", command=self.send_text_box).pack(side="left", padx=6)
        ttk.Checkbutton(right, variable=self.direct_var,
                        text="Digitar direto no box (teclado do PC vira texto)").pack(anchor="w", pady=(6, 0))

        help_txt = (
            "Atalhos do teclado:\n"
            "  Setas = navegar | Enter = OK | Esc/Backspace = Voltar | Home = Tela inicial | F1 = Menu\n"
            "  + / - = Volume | M = Mudo | Espaco = Play/Pause | 0-9 = numeros | Delete = apagar\n"
            "  (com 'Digitar direto' ligado, as letras vao como texto e Backspace apaga)")
        ttk.Label(right, text=help_txt, foreground="gray", justify="left").pack(anchor="w", pady=(8, 0))
        ttk.Label(right, textvariable=self.log_var, foreground="#2a6").pack(anchor="w", pady=(8, 0))

    # ---------- controle desenhado
    @staticmethod
    def _rrect(c, x1, y1, x2, y2, r, **kw):
        pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
               x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
        return c.create_polygon(pts, smooth=True, **kw)

    def _rbtn(self, cx, cy, w, h, label, key, shape="round", bg="#d6d6d6", fg="#222",
              font=("Segoe UI", 11, "bold")):
        c = self.remote
        tag = "btn_%s_%d_%d" % (key, cx, cy)
        if shape == "circle":
            item = c.create_oval(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2,
                                 fill=bg, outline="#9a9a9a", width=2, tags=tag)
        else:
            item = self._rrect(c, cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2, 10,
                               fill=bg, outline="#9a9a9a", width=2, tags=tag)
        c.create_text(cx, cy, text=label, fill=fg, font=font, tags=tag)
        c.tag_bind(tag, "<Button-1>", lambda e, k=key, i=item, b=bg: self._press(k, i, b))
        c.tag_bind(tag, "<Enter>", lambda e: c.config(cursor="hand2"))
        c.tag_bind(tag, "<Leave>", lambda e: c.config(cursor=""))

    def _press(self, key, item, bg):
        self.remote.itemconfig(item, fill="#7be07b")
        self.after(130, lambda: self.remote.itemconfig(item, fill=bg))
        self.send_key(key, confirm=True)

    def _draw_remote(self):
        c = self.remote
        self._rrect(c, 4, 4, 246, 676, 40, fill="#fafafa", outline="#bdbdbd", width=3)
        c.create_text(125, 22, text="in  X plus", fill="#3cb043", font=("Segoe UI", 13, "bold italic"))

        self._rbtn(55, 62, 44, 44, "\u23fb", "POWER", "circle", bg="#e45a5a", fg="white", font=("Segoe UI Symbol", 14, "bold"))
        self._rbtn(125, 62, 44, 44, "Mute", "MUTE", "circle", font=("Segoe UI", 8, "bold"))
        self._rbtn(195, 62, 44, 44, "\u2699", "SETTINGS", "circle", font=("Segoe UI Symbol", 14, "bold"))

        # direcional
        c.create_oval(50, 140, 200, 290, fill="#ececec", outline="#bdbdbd", width=2)
        self._rbtn(125, 168, 44, 40, "\u25b2", "UP", "circle", font=("Segoe UI Symbol", 12))
        self._rbtn(125, 262, 44, 40, "\u25bc", "DOWN", "circle", font=("Segoe UI Symbol", 12))
        self._rbtn(76, 215, 40, 44, "\u25c0", "LEFT", "circle", font=("Segoe UI Symbol", 12))
        self._rbtn(174, 215, 40, 44, "\u25b6", "RIGHT", "circle", font=("Segoe UI Symbol", 12))
        self._rbtn(125, 215, 56, 56, "OK", "OK", "circle", bg="#3cb043", fg="white", font=("Segoe UI", 13, "bold"))

        self._rbtn(55, 330, 62, 36, "Voltar", "BACK", font=("Segoe UI", 9, "bold"))
        self._rbtn(125, 330, 62, 36, "Home", "HOME", font=("Segoe UI", 9, "bold"))
        self._rbtn(195, 330, 62, 36, "Menu", "MENU", font=("Segoe UI", 9, "bold"))

        self._rbtn(55, 385, 62, 36, "Vol -", "VOL_DOWN", font=("Segoe UI", 9, "bold"))
        self._rbtn(125, 385, 62, 36, "\u25b6/\u275a\u275a", "PLAY", font=("Segoe UI Symbol", 9, "bold"))
        self._rbtn(195, 385, 62, 36, "Vol +", "VOL_UP", font=("Segoe UI", 9, "bold"))

        self._rbtn(55, 435, 62, 36, "\u25c0\u25c0", "REW", font=("Segoe UI Symbol", 9, "bold"))
        self._rbtn(125, 435, 62, 36, "\u25a0", "STOP", font=("Segoe UI Symbol", 9, "bold"))
        self._rbtn(195, 435, 62, 36, "\u25b6\u25b6", "FF", font=("Segoe UI Symbol", 9, "bold"))

        rows = [["1", "2", "3"], ["4", "5", "6"], ["7", "8", "9"]]
        y = 495
        for row in rows:
            for i, d in enumerate(row):
                self._rbtn(55 + 70 * i, y, 62, 38, d, d)
            y += 46
        self._rbtn(55, y, 62, 38, "\u232b", "DEL", font=("Segoe UI Symbol", 12, "bold"))
        self._rbtn(125, y, 62, 38, "0", "0")
        self._rbtn(195, y, 62, 38, "\u21b5", "ENTER", font=("Segoe UI Symbol", 12, "bold"))

    def _draw_pad_grid(self):
        self.pad.delete("grid")
        w = int(self.pad["width"])
        h = int(self.pad["height"])
        for i in range(1, 4):
            self.pad.create_line(w * i / 4, 0, w * i / 4, h, fill="#1c232b", tags="grid")
            self.pad.create_line(0, h * i / 4, w, h * i / 4, fill="#1c232b", tags="grid")
        self.pad.create_text(w / 2, h / 2, text="TELA DO BOX", fill="#2b3642",
                             font=("Segoe UI", 22, "bold"), tags="grid")

    # ---------- envio de comandos
    def send_key(self, name, confirm=False):
        if name == "POWER" and confirm:
            if not messagebox.askyesno(
                    "Desligar?",
                    "O botao Power coloca o box em repouso e, sem controle fisico, "
                    "pode ser dificil acorda-lo.\n\nEnviar mesmo assim?"):
                return
        code = KEYS[name]
        self.adb.send("input keyevent %d" % code)
        self.log("tecla: %s" % name)

    def send_text(self, s):
        s = s.replace("\r", "").replace("\n", "")
        if not s:
            return
        t = s.replace(" ", "%s")
        t = "'" + t.replace("'", "'\\''") + "'"
        self.adb.send("input text " + t)
        self.log("texto enviado")

    def send_text_box(self):
        txt = self.text_var.get()
        if any(ord(ch) > 127 for ch in txt):
            self.log("aviso: acentos podem nao funcionar neste Android")
        self.send_text(txt)
        self.text_var.set("")

    # ---------- teclado
    def on_key(self, e):
        w = self.focus_get()
        if isinstance(w, (tk.Entry, ttk.Entry)):
            return
        if e.state & 0x4:  # Ctrl
            return
        ks = e.keysym
        direct = self.direct_var.get()
        name = None
        simple = {"Up": "UP", "Down": "DOWN", "Left": "LEFT", "Right": "RIGHT",
                  "Escape": "BACK", "Home": "HOME", "F1": "MENU", "Delete": "DEL"}
        if ks in simple:
            name = simple[ks]
        elif ks in ("Return", "KP_Enter"):
            name = "ENTER" if direct else "OK"
        elif ks == "BackSpace":
            name = "DEL" if direct else "BACK"
        elif not direct:
            if ks in ("plus", "KP_Add", "equal"):
                name = "VOL_UP"
            elif ks in ("minus", "KP_Subtract"):
                name = "VOL_DOWN"
            elif ks in ("m", "M"):
                name = "MUTE"
            elif ks == "space":
                name = "PLAY"
            elif e.char and e.char.isdigit():
                name = e.char
        if name:
            now = time.time()
            if now - self._last_key.get(name, 0) < 0.15:  # evita fila com tecla segurada
                return "break"
            self._last_key[name] = now
            self.send_key(name)
            return "break"
        if direct and e.char and e.char.isprintable():
            self.send_text(e.char)
            return "break"

    # ---------- mouse
    def _to_screen(self, x, y):
        w = int(self.pad["width"])
        h = int(self.pad["height"])
        x = min(max(x, 0), w)
        y = min(max(y, 0), h)
        return int(x * self.scr[0] / w), int(y * self.scr[1] / h)

    def pad_press(self, e):
        self._p0 = (e.x, e.y, time.time())

    def pad_release(self, e):
        if not self._p0:
            return
        x0, y0, t0 = self._p0
        self._p0 = None
        if abs(e.x - x0) < 8 and abs(e.y - y0) < 8:
            sx, sy = self._to_screen(e.x, e.y)
            self.adb.send("input tap %d %d" % (sx, sy))
            self._blip(e.x, e.y)
            self.log("toque em %d,%d" % (sx, sy))
        else:
            ax, ay = self._to_screen(x0, y0)
            bx, by = self._to_screen(e.x, e.y)
            dur = int(max(120, min(1500, (time.time() - t0) * 1000)))
            self.adb.send("input swipe %d %d %d %d %d" % (ax, ay, bx, by, dur))
            self.log("deslizar")

    def pad_wheel(self, e):
        cx, cy = self.scr[0] // 2, self.scr[1] // 2
        d = self.scr[1] // 4
        if e.delta > 0:   # roda para cima: o conteudo desce
            self.adb.send("input swipe %d %d %d %d 220" % (cx, cy - d, cx, cy + d))
        else:
            self.adb.send("input swipe %d %d %d %d 220" % (cx, cy + d, cx, cy - d))
        self.log("rolar")

    def _blip(self, x, y):
        i = self.pad.create_oval(x - 8, y - 8, x + 8, y + 8, outline="#3cb043", width=2)
        self.after(250, lambda: self.pad.delete(i))

    # ---------- conexao
    def pick_adb(self):
        p = filedialog.askopenfilename(title="Escolha o adb.exe",
                                       filetypes=[("adb", "adb.exe adb"), ("Todos", "*.*")])
        if p:
            self.adb.close()
            self.adb.path = p
            self.cfg["adb"] = p
            save_config(self.cfg)
            self.do_connect()

    def do_connect(self):
        ip = self.ip_var.get().strip()
        if not ip:
            return
        if ":" not in ip:
            ip += ":5555"
            self.ip_var.set(ip)
        self.set_status("Conectando...", "#c80")

        def work():
            _, out = self.adb.run(["connect", ip], timeout=12)
            low = out.lower()
            ok = "connected" in low and "cannot" not in low and "failed" not in low
            if not ok:
                self.ui(lambda: self.set_status("Falha: " + out.strip()[:80], "#c22"))
                return
            self.adb.serial = ip
            self.adb.open_shell()
            _, o2 = self.adb.run(["-s", ip, "shell", "wm size"], timeout=8)
            m = re.findall(r"(\d+)x(\d+)", o2)
            if m:
                self.scr = (int(m[-1][0]), int(m[-1][1]))
            self.cfg["ip"] = ip
            save_config(self.cfg)

            def done():
                h = int(PAD_W * self.scr[1] / self.scr[0])
                self.pad.config(height=h)
                self._draw_pad_grid()
                self.set_status("Conectado a %s (%dx%d)" % (ip, self.scr[0], self.scr[1]), "#2a6")
            self.ui(done)

        threading.Thread(target=work, daemon=True).start()

    # ---------- ferramentas
    def open_scrcpy(self):
        d = os.path.dirname(self.adb.path)
        exe = os.path.join(d, "scrcpy.exe")
        if not os.path.isfile(exe):
            exe = shutil.which("scrcpy")
        if not exe:
            messagebox.showinfo("scrcpy", "scrcpy nao encontrado ao lado do adb.exe.")
            return
        args = [exe]
        if self.adb.serial:
            args += ["-s", self.adb.serial]
        try:
            subprocess.Popen(args, cwd=os.path.dirname(exe))
            self.log("scrcpy aberto")
        except OSError as ex:
            messagebox.showerror("scrcpy", str(ex))

    def close_focused(self):
        if not self.adb.serial:
            self.log("conecte primeiro")
            return

        def work():
            _, out = self.adb.run(["-s", self.adb.serial, "shell", "dumpsys window"], timeout=20)
            m = re.search(r"mCurrentFocus=Window\{\S+ \S+ ([\w.]+)/", out)
            if not m:
                m = re.search(r"ActivityRecord\{\S+ \S+ ([\w.]+)/", out.split("mFocusedApp", 1)[-1])
            pkg = m.group(1) if m else None
            if not pkg or pkg in PROTECTED_PKGS:
                self.adb.send("input keyevent 3")
                self.ui(lambda: self.log("ja esta na tela inicial/sistema"))
                return
            self.adb.send("am force-stop %s" % pkg)
            self.adb.send("input keyevent 3")
            self.ui(lambda: self.log("app fechado: %s" % pkg))

        threading.Thread(target=work, daemon=True).start()

    def enable_launcher(self):
        self.adb.send("pm enable %s" % LAUNCHER_PKG)
        self.adb.send("input keyevent 3")
        self.log("launcher XPLUS reativado")

    def on_close(self):
        self.adb.close()
        save_config(self.cfg)
        self.destroy()


if __name__ == "__main__":
    App().mainloop()

