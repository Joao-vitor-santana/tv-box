# XPLUS TV Box — handoff para outra IA

Este repositório reúne o histórico técnico, o código do launcher e do controle ADB e os resultados de medição deste projeto. O material foi sanitizado para compartilhamento: endereços locais e caminhos pessoais foram removidos.

## Estado atual

- TV Box XPLUS, placa reportada como p281, Android legado (firmware anuncia Android 7.1.2/API 25; o sistema também reporta API 29 em alguns comandos).
- Launcher atual: `com.olive.xpluslauncher/.HomeActivity`, instalado e definido como HOME.
- O app oficial `com.google.android.youtube.tv` está instalado e o tile do launcher abre esse app. O app ainda exibe “Este dispositivo não é compatível com o YouTube”; a causa não foi resolvida. A tentativa mínima de adicionar a feature Leanback não apareceu em `pm list features` após reboot.
- Reinstalação automática de apps removidos: identificada no componente `realplay.com.timeserver/.install.installApkReceiver`, dentro de `TimeServer.apk`. O receptor foi desativado para o user 0; o serviço principal TimeServer foi preservado. Após reiniciar, o estado desativado foi confirmado.
- O launcher OEM atualizado foi removido para o user 0. O APK OEM de sistema não foi apagado manualmente.
- Backup integral de eMMC foi feito antes das alterações. A imagem inclui dados privados e não está neste repositório.

## Histórico

Leia `CHAT-HISTORY.md` para a cronologia dos pedidos, alterações, testes, limitações e situação de cada item.

## Arquivos

- `custom_launcher/src`: código Android do launcher, com UI azul, tema escuro/normal, favoritos fixáveis, gaveta de apps e fluxo de desinstalação.
- `custom_launcher/XPLUS-Home-Leve.apk`: APK gerado e instalado no aparelho (29.156 bytes neste estado).
- `custom_launcher/build.ps1`: script de build; requer Android SDK e JDK locais. A keystore original de assinatura não está incluída; sem ela, uma atualização in-place pode exigir reinstalação.
- `controle/controle_xplus.py`: controle remoto Tkinter/ADB; a configuração foi sanitizada.
- `performance-comparison.txt`: medições antes/depois registradas na sessão.
- `backup-sha256.txt`: hashes dos backups locais; os arquivos de imagem correspondentes não estão no repositório.
- `android-backup-notes.txt`: notas sobre o backup e cuidados de restauração.
- `custom_launcher/preview-*.png`: capturas de desenvolvimento da interface.

## Material deliberadamente não incluído

Não publique ou envie para serviços externos `mmcblk0-full.img`, `super-original.img`, `mmcblk0boot*.bin`, os APKs OEM/YouTube do firmware, dados de propriedades do sistema, a keystore privada ou a pasta completa `backups/android-full`. A imagem integral contém os dados do usuário e as imagens de firmware são grandes. Elas permanecem localmente em `backups/`.

## Reconexão ADB

Edite `controle/controle_xplus_config.example.json` para substituir `TVBOX_IP:5555` pelo endereço atual do aparelho e configure o caminho do `adb` se necessário. Não reutilize endereços antigos sem confirmar que ainda são válidos.
