package com.olive.xpluslauncher;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

public final class HomeActivity extends Activity {
    private HomeView homeView;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        homeView = new HomeView(this);
        setContentView(homeView);
        hideSystemBars();
    }

    @Override public void onWindowFocusChanged(boolean focused) {
        super.onWindowFocusChanged(focused);
        if (focused) hideSystemBars();
    }

    @Override public void onBackPressed() {
        if (homeView != null) homeView.goHome();
        else super.onBackPressed();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 41 && homeView != null) homeView.refreshApps();
    }

    private void hideSystemBars() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private static final class AppItem {
        final String packageName;
        final String label;
        final Intent launchIntent;
        final Drawable icon;
        final boolean system;

        AppItem(String pkg, String name, Intent intent, Drawable image, boolean isSystem) {
            packageName = pkg;
            label = name;
            launchIntent = intent;
            icon = image;
            system = isSystem;
        }
    }

    private static final class Target {
        final RectF bounds;
        final String kind;
        final String label;
        final AppItem app;
        Target(RectF rect, String type, String name, AppItem item) {
            bounds = rect;
            kind = type;
            label = name;
            app = item;
        }
    }

    private final class HomeView extends View {
        private static final int BASE_W = 1280;
        private static final int BASE_H = 720;
        // Android 7 uses this PackageManager flag, but omits the public constant.
        private static final int MATCH_STOPPED_PACKAGES_FLAG = 0x00000020;
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
        private final List<AppItem> apps = new ArrayList<AppItem>();
        private final List<AppItem> favorites = new ArrayList<AppItem>();
        private final List<Target> targets = new ArrayList<Target>();
        private final Map<String, AppItem> byPackage = new HashMap<String, AppItem>();
        private final Set<String> videoPackages = new HashSet<String>();
        private final Set<String> pinnedPackages = new HashSet<String>();
        private final Handler handler = new Handler();
        private final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", new Locale("pt", "BR"));
        private final SimpleDateFormat dateFormat = new SimpleDateFormat("EEE, dd/MM/yyyy", new Locale("pt", "BR"));
        private String screen = "HOME";
        private int section = 0;
        private int focus = 0;
        private int page = 0;
        private String searchQuery = "";
        private float scaleX = 1f;
        private float scaleY = 1f;
        private long lastClockUpdate;
        private String timeText = "";
        private String dateText = "";
        private boolean darkMode = true;
        private int touchTarget = -1;
        private float touchX, touchY;
        private boolean dragging = false;
        private boolean drawTrash = false;
        private float dragX, dragY;
        private boolean longPressFired = false;
        private final Runnable touchLongPress = new Runnable() { @Override public void run() { if (touchTarget >= 0 && touchTarget < targets.size() && "APPS".equals(screen) && "APP".equals(targets.get(touchTarget).kind)) { longPressFired = true; confirmUninstall(targets.get(touchTarget).app); } } };
        private int heldKey = -1;
        private final Runnable keyLongPress = new Runnable() { @Override public void run() { if ((heldKey == KeyEvent.KEYCODE_DPAD_CENTER || heldKey == KeyEvent.KEYCODE_ENTER || heldKey == KeyEvent.KEYCODE_NUMPAD_ENTER) && "APPS".equals(screen) && focus >= 0 && focus < targets.size() && "APP".equals(targets.get(focus).kind)) { longPressFired = true; confirmUninstall(targets.get(focus).app); } } };

        HomeView(Context context) {
            super(context);
            setFocusable(true);
            setFocusableInTouchMode(true);
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
            text.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            loadApps();
            android.content.SharedPreferences prefs = context.getSharedPreferences("launcher", MODE_PRIVATE);
            darkMode = prefs.getBoolean("dark", true);
            Set<String> savedPins = prefs.getStringSet("pinned", null);
            if (savedPins == null) { pinnedPackages.add("com.google.android.youtube.tv"); pinnedPackages.add("com.netflix.mediaclient"); }
            else pinnedPackages.addAll(savedPins);
            rebuildFavorites();
            focus = 13;
            updateClock();
            postDelayed(clockTick, 60000L);
        }

        private final Runnable clockTick = new Runnable() {
            @Override public void run() {
                updateClock();
                invalidate();
                postDelayed(this, 60000L);
            }
        };

        private void updateClock() {
            Date now = new Date();
            timeText = timeFormat.format(now);
            dateText = dateFormat.format(now);
            lastClockUpdate = now.getTime();
        }

        private void loadApps() {
            PackageManager pm = getPackageManager();
            Intent query = new Intent(Intent.ACTION_MAIN, null);
            query.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> launchables = pm.queryIntentActivities(query, MATCH_STOPPED_PACKAGES_FLAG);
            for (ResolveInfo ri : launchables) {
                if (ri.activityInfo == null || ri.activityInfo.applicationInfo == null) continue;
                ApplicationInfo ai = ri.activityInfo.applicationInfo;
                String pkg = ai.packageName;
                if (pkg.equals(getPackageName()) || pkg.equals("com.xbs.xplus") || pkg.startsWith("com.xbs.otaupdate") || byPackage.containsKey(pkg)) continue;
                int enabledState;
                try { enabledState = pm.getApplicationEnabledSetting(pkg); }
                catch (Exception ignored) { continue; }
                if (!ai.enabled || enabledState == PackageManager.COMPONENT_ENABLED_STATE_DISABLED ||
                        enabledState == PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER ||
                        enabledState == PackageManager.COMPONENT_ENABLED_STATE_DISABLED_UNTIL_USED) continue;
                Intent launch = new Intent(Intent.ACTION_MAIN);
                launch.addCategory(Intent.CATEGORY_LAUNCHER);
                launch.setClassName(pkg, ri.activityInfo.name);
                String name = String.valueOf(ri.loadLabel(pm));
                boolean systemApp = (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                AppItem item = new AppItem(pkg, name, launch, ri.loadIcon(pm), systemApp);
                byPackage.put(pkg, item);
                apps.add(item);
            }
            Collections.sort(apps, new Comparator<AppItem>() {
                @Override public int compare(AppItem a, AppItem b) {
                    return a.label.compareToIgnoreCase(b.label);
                }
            });

            String[] preferred = new String[] {
                "com.google.android.youtube.tv", "com.netflix.mediaclient", "com.amazon.avod.thirdpartyclient",
                "com.disney.disneyplus", "br.com.globo.play", "com.globo.globotv",
                "com.spotify.tv.android", "com.spotify.music", "com.android.vending"
            };
            for (String pkg : preferred) { AppItem item = byPackage.get(pkg); if (item != null && pinnedPackages.contains(pkg)) favorites.add(item); }
            for (String pkg : new String[] {"com.example.playback4mitv", "com.newvod.app", "com.liveb2.app", "com.smalls.xplussports"}) {
                videoPackages.add(pkg);
            }
        }

        @Override protected void onSizeChanged(int w, int h, int oldW, int oldH) {
            scaleX = w / (float) BASE_W;
            scaleY = h / (float) BASE_H;
        }

        @Override protected void onDraw(Canvas raw) {
            super.onDraw(raw);
            Canvas c = raw;
            c.save();
            c.scale(scaleX, scaleY);
            drawBackdrop(c);
            targets.clear();
            if ("HOME".equals(screen)) drawHome(c);
            else drawAppPage(c);
            c.restore();
        }

        private void drawBackdrop(Canvas c) {
            paint.setShader(new LinearGradient(0, 0, BASE_W, BASE_H,
                    darkMode ? new int[] {Color.rgb(3, 12, 39), Color.rgb(12, 37, 91), Color.rgb(4, 15, 49)} : new int[] {Color.rgb(7, 27, 84), Color.rgb(21, 67, 153), Color.rgb(8, 27, 82)},
                    null, Shader.TileMode.CLAMP));
            c.drawRect(0, 0, BASE_W, BASE_H, paint);
            paint.setShader(null);

            Path ribbon = new Path();
            ribbon.moveTo(300, -40); ribbon.cubicTo(420, 100, 600, 130, 760, 60);
            ribbon.cubicTo(970, -30, 1115, 55, 1310, 165); ribbon.lineTo(1310, 340);
            ribbon.cubicTo(1100, 175, 940, 185, 770, 275); ribbon.cubicTo(565, 385, 390, 225, 300, -40);
            ribbon.close();
            paint.setShader(new LinearGradient(250, 0, 1100, 300,
                    new int[] {Color.argb(85, 116, 180, 255), Color.argb(38, 60, 129, 255), Color.argb(7, 255, 255, 255)},
                    null, Shader.TileMode.CLAMP));
            c.drawPath(ribbon, paint);
            paint.setShader(null);

            Path wave = new Path();
            wave.moveTo(270, 720); wave.cubicTo(440, 535, 660, 570, 810, 405);
            wave.cubicTo(980, 225, 1110, 250, 1300, 112); wave.lineTo(1300, 515);
            wave.cubicTo(1100, 600, 920, 705, 760, 720); wave.close();
            paint.setShader(new LinearGradient(600, 310, 1190, 700,
                    new int[] {Color.argb(10, 255, 255, 255), Color.argb(48, 74, 163, 255), Color.argb(16, 231, 75, 255)},
                    null, Shader.TileMode.CLAMP));
            c.drawPath(wave, paint);
            paint.setShader(null);

            paint.setStyle(Paint.Style.STROKE);
            paint.setStrokeWidth(2f);
            paint.setColor(Color.argb(42, 216, 236, 255));
            c.drawPath(ribbon, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        private void drawHome(Canvas c) {
            drawStatus(c);
            drawSidebar(c);
            drawWelcome(c);
            drawTopButton(c, addTarget(752, 31, 112, 38, "PINMODE", "Fixar apps", null), "Fixar apps");
            drawTopButton(c, addTarget(874, 31, 112, 38, "THEME", darkMode ? "Modo normal" : "Modo escuro", null), darkMode ? "Modo normal" : "Modo escuro");
            drawUtility(c, 7, "memory", "Limpeza", "de Memória", 810, 178);
            drawUtility(c, 8, "speed", "Otimizar", "Sistema", 1040, 178);
            drawUtility(c, 9, "folder", "Meus Arquivos", "", 810, 288);
            drawUtility(c, 10, "gear", "Configurações", "", 1040, 288);

            int n = favorites.size();
            for (int i = 0; i < n; i++) {
                float x = 130 + i * 142;
                Target t = addTarget(x, 464, 116, 150, "APP", favorites.get(i).label, favorites.get(i));
                drawAppTile(c, t, favorites.get(i), false);
            }
            float drawerX = 130 + n * 142;
            Target drawer = addTarget(drawerX, 464, 116, 150, "APPS", "Todos os Apps", null);
            drawDrawerTile(c, drawer);
        }

        private void drawStatus(Canvas c) {
            float x = 1006, y = 48;
            drawWifi(c, x, y);
            drawBluetooth(c, x + 49, y);
            drawBell(c, x + 98, y);
            paint.setColor(Color.argb(170, 240, 247, 255));
            c.drawRect(x + 137, 29, x + 139, 67, paint);
            text.setColor(Color.WHITE); text.setTextAlign(Paint.Align.RIGHT); text.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
            text.setTextSize(29); c.drawText(timeText, 1220, 51, text);
            text.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL)); text.setTextSize(13);
            c.drawText(dateText, 1220, 72, text);
        }

        private void drawTopButton(Canvas c, Target t, String label) {
            RectF r=t.bounds; boolean selected=targets.indexOf(t)==focus;
            paint.setColor(selected?Color.argb(165,35,148,242):Color.argb(90,180,210,255)); c.drawRoundRect(r,14,14,paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(selected?2.5f:1f); paint.setColor(selected?Color.rgb(102,225,255):Color.argb(100,255,255,255)); c.drawRoundRect(r,14,14,paint); paint.setStyle(Paint.Style.FILL);
            text.setTextAlign(Paint.Align.CENTER);text.setTextSize(13);text.setTypeface(Typeface.create("sans-serif-medium",0));text.setColor(Color.WHITE);c.drawText(label,r.centerX(),r.centerY()+5,text);
        }

        private void drawSidebar(Canvas c) {
            paint.setShader(new LinearGradient(14, 150, 99, 638,
                    Color.argb(95, 182, 214, 255), Color.argb(44, 96, 151, 247), Shader.TileMode.CLAMP));
            c.drawRoundRect(15, 150, 96, 642, 40, 40, paint);
            paint.setShader(null);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.5f); paint.setColor(Color.argb(55, 255, 255, 255));
            c.drawRoundRect(15, 150, 96, 642, 40, 40, paint); paint.setStyle(Paint.Style.FILL);
            String[] names = {"home", "search", "apps", "movies", "tv", "settings", "power"};
            for (int i = 0; i < names.length; i++) {
                float top = 174 + i * 66;
                RectF r = new RectF(22, top, 89, top + 55);
                Target t = addTarget(r, "NAV", names[i], null);
                if (section == i) {
                    paint.setShader(new LinearGradient(r.left, r.top, r.right, r.bottom,
                            new int[] {Color.argb(215, 31, 164, 255), Color.argb(160, 35, 101, 238)},
                            null, Shader.TileMode.CLAMP));
                    c.drawRoundRect(r, 18, 18, paint); paint.setShader(null);
                    paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2); paint.setColor(Color.argb(220, 97, 225, 255));
                    c.drawRoundRect(r, 18, 18, paint); paint.setStyle(Paint.Style.FILL);
                }
                drawIcon(c, names[i], 55, top + 27, 28, Color.rgb(222, 240, 255));
                drawFocus(c, t);
            }
        }

        private void drawWelcome(Canvas c) {
            text.setTextAlign(Paint.Align.LEFT); text.setColor(Color.WHITE);
            text.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); text.setTextSize(61);
            c.drawText("Olá!", 140, 267, text);
            text.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL)); text.setTextSize(42);
            text.setColor(Color.rgb(205, 224, 255)); c.drawText("Bem-vindo de volta!", 143, 317, text);
            text.setTextSize(20); text.setColor(Color.rgb(210, 228, 255));
            c.drawText("Explore seus apps e aproveite o melhor da sua TV.", 145, 353, text);
        }

        private void drawUtility(Canvas c, int targetId, String icon, String line1, String line2, float x, float y) {
            Target t = addTarget(x, y, 218, 98, "UTILITY", icon, null);
            paint.setShader(new LinearGradient(x, y, x + 218, y + 98,
                    new int[] {Color.argb(115, 204, 224, 255), Color.argb(72, 107, 152, 255)},
                    null, Shader.TileMode.CLAMP));
            c.drawRoundRect(x, y, x + 218, y + 98, 28, 28, paint); paint.setShader(null);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(1.5f); paint.setColor(Color.argb(82, 255, 255, 255));
            c.drawRoundRect(x, y, x + 218, y + 98, 28, 28, paint); paint.setStyle(Paint.Style.FILL);
            drawIcon(c, icon, x + 52, y + 49, 42, Color.rgb(222, 239, 255));
            text.setColor(Color.WHITE); text.setTextAlign(Paint.Align.LEFT); text.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            text.setTextSize(16);
            float ty = line2.length() == 0 ? y + 57 : y + 42;
            c.drawText(line1, x + 94, ty, text);
            if (line2.length() > 0) c.drawText(line2, x + 94, ty + 21, text);
        }

        private void drawAppTile(Canvas c, Target t, AppItem app, boolean compact) {
            float x = t.bounds.left, y = t.bounds.top;
            boolean focused = targets.indexOf(t) == focus;
            if (focused) {
                paint.setColor(Color.argb(90, 64, 185, 255));
                c.drawRoundRect(x - 4, y - 4, x + t.bounds.width() + 4, y + 120, 28, 28, paint);
            } else {
                paint.setColor(Color.argb(65, 214, 230, 255));
                c.drawRoundRect(x, y, x + t.bounds.width(), y + 112, 27, 27, paint);
            }
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(focused ? 2.5f : 1f);
            paint.setColor(focused ? Color.rgb(104, 225, 255) : Color.argb(70, 255, 255, 255));
            c.drawRoundRect(x, y, x + t.bounds.width(), y + 112, 27, 27, paint); paint.setStyle(Paint.Style.FILL);
            if (app.icon != null) {
                int inset = compact ? 27 : 19;
                app.icon.setBounds((int) (x + inset), (int) (y + inset), (int) (x + t.bounds.width() - inset), (int) (y + 112 - inset));
                app.icon.draw(c);
            }
            text.setTextAlign(Paint.Align.CENTER); text.setColor(Color.WHITE); text.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); text.setTextSize(14);
            c.drawText(shortLabel(app.label, 15), x + t.bounds.width() / 2, y + 138, text);
        }

        private void drawDrawerTile(Canvas c, Target t) {
            float x = t.bounds.left, y = t.bounds.top;
            boolean focused = targets.indexOf(t) == focus;
            paint.setColor(focused ? Color.argb(130, 76, 129, 255) : Color.argb(68, 210, 225, 255));
            c.drawRoundRect(x, y, x + 116, y + 112, 27, 27, paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2); paint.setColor(Color.argb(125, 255, 255, 255));
            c.drawRoundRect(x, y, x + 116, y + 112, 27, 27, paint); paint.setStyle(Paint.Style.FILL);
            drawIcon(c, "apps", x + 58, y + 53, 42, Color.WHITE);
            text.setColor(Color.WHITE); text.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); text.setTextSize(14); text.setTextAlign(Paint.Align.CENTER);
            c.drawText("Todos os Apps", x + 58, y + 138, text);
        }

        private void drawAppPage(Canvas c) {
            drawStatus(c);
            drawSidebar(c);
            boolean pinMode="PIN".equals(screen);
            String title = pinMode ? "Fixar aplicativos na tela inicial" : section == 1 ? (searchQuery.length() == 0 ? "Buscar aplicativos" : "Busca: " + searchQuery) : section == 3 ? "Filmes e séries" : section == 4 ? "TV e entretenimento" : "Todos os aplicativos";
            text.setColor(Color.WHITE); text.setTextAlign(Paint.Align.LEFT); text.setTypeface(Typeface.create("sans-serif", Typeface.BOLD)); text.setTextSize(35);
            c.drawText(title, 140, 105, text);
            List<AppItem> visible = getVisibleApps();
            int start = page * 12;
            int end = Math.min(start + 12, visible.size());
            for (int i = start; i < end; i++) {
                int slot = i - start;
                int row = slot / 4, col = slot % 4;
                float x = 130 + col * 278, y = 142 + row * 132;
                AppItem app = visible.get(i);
                Target t = addTarget(x, y, 236, 112, pinMode ? "PINAPP" : "APP", app.label, app);
                drawGridApp(c, t, app);
                if (pinMode && pinnedPackages.contains(app.packageName)) { text.setTextAlign(Paint.Align.RIGHT);text.setTextSize(13);text.setColor(Color.WHITE);c.drawText("FIXADO",x+220,y+96,text); }
            }
            if (pinMode) { Target back=addTarget(1000,600,190,48,"PINBACK","Concluir",null);drawTopButton(c,back,"Concluir"); }
            if (visible.isEmpty()) {
                text.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL)); text.setTextSize(20); text.setColor(Color.rgb(218, 232, 255));
                c.drawText("Nenhum aplicativo disponível nesta categoria.", 150, 200, text);
            }
            text.setTextAlign(Paint.Align.CENTER); text.setTextSize(14); text.setColor(Color.argb(205, 236, 245, 255));
            String hint = pinMode ? "Selecione os aplicativos que deseja mostrar na tela inicial" : visible.size() > 12 ? "Use ◀ / ▶ para mudar de página  •  Voltar para a tela inicial" : "Segure OK para desinstalar • Voltar para a tela inicial";
            c.drawText(hint, 700, 646, text);
            if(drawTrash){paint.setColor(Color.argb(230,170,30,48));c.drawRoundRect(1035,580,1240,660,22,22,paint);text.setTextAlign(Paint.Align.CENTER);text.setTextSize(17);text.setColor(Color.WHITE);c.drawText("Solte para desinstalar",1137,626,text);}
        }

        private void drawGridApp(Canvas c, Target t, AppItem app) {
            RectF r = t.bounds;
            boolean selected = targets.indexOf(t) == focus;
            paint.setColor(selected ? Color.argb(135, 64, 148, 255) : Color.argb(72, 195, 220, 255));
            c.drawRoundRect(r, 22, 22, paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(selected ? 2.5f : 1f);
            paint.setColor(selected ? Color.rgb(104, 225, 255) : Color.argb(70, 255, 255, 255));
            c.drawRoundRect(r, 22, 22, paint); paint.setStyle(Paint.Style.FILL);
            if (app.icon != null) {
                app.icon.setBounds((int) r.left + 15, (int) r.top + 20, (int) r.left + 75, (int) r.top + 80);
                app.icon.draw(c);
            }
            text.setColor(Color.WHITE); text.setTextAlign(Paint.Align.LEFT); text.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL)); text.setTextSize(15);
            c.drawText(shortLabel(app.label, 24), r.left + 88, r.top + 61, text);
        }

        private List<AppItem> getVisibleApps() {
            if (section == 3) return favorites;
            if (section == 4) {
                List<AppItem> tv = new ArrayList<AppItem>();
                for (AppItem app : apps) if (videoPackages.contains(app.packageName)) tv.add(app);
                return tv;
            }
            if (section == 1 && searchQuery.length() > 0) {
                List<AppItem> filtered = new ArrayList<AppItem>();
                String q = searchQuery.toLowerCase(Locale.ROOT);
                for (AppItem app : apps) if (app.label.toLowerCase(Locale.ROOT).contains(q) || app.packageName.toLowerCase(Locale.ROOT).contains(q)) filtered.add(app);
                return filtered;
            }
            return apps;
        }

        private Target addTarget(float x, float y, float w, float h, String kind, String label, AppItem app) {
            Target t = new Target(new RectF(x, y, x + w, y + h), kind, label, app);
            targets.add(t);
            return t;
        }

        private Target addTarget(RectF rect, String kind, String label, AppItem app) {
            Target t = new Target(rect, kind, label, app);
            targets.add(t);
            return t;
        }

        private void drawFocus(Canvas c, Target t) {
            if (targets.indexOf(t) != focus) return;
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(2f); paint.setColor(Color.argb(220, 137, 230, 255));
            c.drawRoundRect(t.bounds.left - 2, t.bounds.top - 2, t.bounds.right + 2, t.bounds.bottom + 2, 24, 24, paint);
            paint.setStyle(Paint.Style.FILL);
        }

        private void drawIcon(Canvas c, String type, float cx, float cy, float size, int color) {
            paint.setColor(color); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(Math.max(2f, size * 0.085f));
            paint.setStrokeCap(Paint.Cap.ROUND); paint.setStrokeJoin(Paint.Join.ROUND);
            float r = size * 0.43f;
            if ("home".equals(type)) {
                Path p = new Path(); p.moveTo(cx-r, cy); p.lineTo(cx, cy-r*0.88f); p.lineTo(cx+r, cy); p.lineTo(cx+r*0.7f, cy); p.lineTo(cx+r*0.7f, cy+r*0.9f); p.lineTo(cx+r*0.18f, cy+r*0.9f); p.lineTo(cx+r*0.18f, cy+r*0.25f); p.lineTo(cx-r*0.18f, cy+r*0.25f); p.lineTo(cx-r*0.18f, cy+r*0.9f); p.lineTo(cx-r*0.7f, cy+r*0.9f); p.lineTo(cx-r*0.7f, cy); p.close(); c.drawPath(p, paint);
            } else if ("search".equals(type)) {
                c.drawCircle(cx-size*0.12f, cy-size*0.12f, size*0.27f, paint); c.drawLine(cx+size*0.08f, cy+size*0.08f, cx+size*0.36f, cy+size*0.36f, paint);
            } else if ("apps".equals(type)) {
                float d=size*0.24f, gap=size*0.10f; for(int row=0;row<2;row++) for(int col=0;col<2;col++){ float x=cx-(d+gap/2)+(col*(d+gap)); float y=cy-(d+gap/2)+(row*(d+gap)); c.drawRoundRect(x-d/2,y-d/2,x+d/2,y+d/2,4,4,paint); }
            } else if ("movies".equals(type)) {
                c.drawRoundRect(cx-r,cy-size*.2f,cx+r,cy+r*.75f,5,5,paint); c.drawLine(cx-r,cy-size*.2f,cx-r*.75f,cy-r*.75f,paint); c.drawLine(cx-r*.75f,cy-r*.75f,cx+r,cy-size*.2f,paint); c.drawLine(cx-size*.3f,cy-size*.45f,cx-size*.15f,cy-size*.2f,paint); c.drawLine(cx+size*.12f,cy-size*.38f,cx+size*.28f,cy-size*.2f,paint);
            } else if ("tv".equals(type)) {
                c.drawRoundRect(cx-r,cy-size*.25f,cx+r,cy+r*.65f,5,5,paint); c.drawLine(cx-size*.18f,cy-size*.28f,cx-size*.42f,cy-size*.56f,paint); c.drawLine(cx-size*.18f,cy-size*.28f,cx+size*.12f,cy-size*.56f,paint); c.drawLine(cx-size*.28f,cy+r*.85f,cx+size*.28f,cy+r*.85f,paint);
            } else if ("power".equals(type)) {
                c.drawArc(cx-r,cy-r,cx+r,cy+r,135,270,false,paint); c.drawLine(cx,cy-r*1.15f,cx,cy+size*.02f,paint);
            } else if ("folder".equals(type)) {
                c.drawRoundRect(cx-r,cy-r*.35f,cx+r,cy+r*.7f,5,5,paint); c.drawLine(cx-r,cy-r*.35f,cx-r*.38f,cy-r*.65f,paint); c.drawLine(cx-r*.38f,cy-r*.65f,cx+r*.1f,cy-r*.65f,paint); c.drawLine(cx+r*.1f,cy-r*.65f,cx+r*.3f,cy-r*.35f,paint);
            } else if ("memory".equals(type)) {
                Path p=new Path(); p.moveTo(cx,cy-r);p.lineTo(cx+r*.72f,cy-r*.25f);p.lineTo(cx+r*.45f,cy+r*.45f);p.lineTo(cx,cy+r);p.lineTo(cx-r*.48f,cy+r*.45f);p.lineTo(cx-r*.75f,cy-r*.18f);p.close();c.drawPath(p,paint);c.drawLine(cx,cy-r*.58f,cx,cy+r*.62f,paint);
            } else if ("speed".equals(type)) {
                c.drawArc(cx-r,cy-r,cx+r,cy+r,135,270,false,paint);c.drawLine(cx,cy,cx+r*.55f,cy-r*.4f,paint);c.drawCircle(cx,cy,3,paint);
            } else if ("gear".equals(type) || "settings".equals(type)) {
                c.drawCircle(cx,cy,size*.28f,paint);c.drawCircle(cx,cy,size*.1f,paint);
                for(int i=0;i<8;i++){double a=Math.PI*i/4;float x1=(float)Math.cos(a)*size*.32f, y1=(float)Math.sin(a)*size*.32f;float x2=(float)Math.cos(a)*size*.46f,y2=(float)Math.sin(a)*size*.46f;c.drawLine(cx+x1,cy+y1,cx+x2,cy+y2,paint);}
            } else if ("bluetooth".equals(type)) {
                c.drawLine(cx,cy-r,cx,cy+r,paint);c.drawLine(cx,cy-r,cx+r*.6f,cy-r*.45f,paint);c.drawLine(cx+r*.6f,cy-r*.45f,cx-r*.45f,cy+r*.45f,paint);c.drawLine(cx-r*.45f,cy-r*.4f,cx+r*.6f,cy+r*.45f,paint);c.drawLine(cx+r*.6f,cy+r*.45f,cx,cy+r,paint);
            } else if ("bell".equals(type)) {
                Path p=new Path();p.moveTo(cx-r*.72f,cy+r*.45f);p.quadTo(cx-r*.4f,cy+r*.12f,cx-r*.4f,cy-r*.28f);p.quadTo(cx,cy-r*.9f,cx+r*.4f,cy-r*.28f);p.quadTo(cx+r*.4f,cy+r*.12f,cx+r*.72f,cy+r*.45f);p.close();c.drawPath(p,paint);c.drawCircle(cx,cy+r*.62f,size*.08f,paint);
            }
            paint.setStyle(Paint.Style.FILL); paint.setStrokeCap(Paint.Cap.BUTT);
        }

        private void drawWifi(Canvas c, float cx, float cy) {
            paint.setColor(Color.rgb(226, 239, 255)); paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(3);
            c.drawArc(cx-15,cy-10,cx+15,cy+15,220,100,false,paint); c.drawArc(cx-10,cy-5,cx+10,cy+12,220,100,false,paint);
            paint.setStyle(Paint.Style.FILL); c.drawCircle(cx,cy+9,2.7f,paint);
        }

        private void drawBluetooth(Canvas c, float x, float y) { drawIcon(c,"bluetooth",x,y,24,Color.rgb(226,239,255)); }
        private void drawBell(Canvas c, float x, float y) { drawIcon(c,"bell",x,y,23,Color.rgb(226,239,255)); }

        private String shortLabel(String s, int max) {
            if (s == null || s.length() <= max) return s == null ? "" : s;
            return s.substring(0, Math.max(1, max - 1)) + "…";
        }

        @Override public boolean onTouchEvent(MotionEvent e) {
            float x=e.getX()/scaleX,y=e.getY()/scaleY;
            if(e.getAction()==MotionEvent.ACTION_DOWN){touchX=x;touchY=y;touchTarget=-1;longPressFired=false;dragging=false;for(int i=targets.size()-1;i>=0;i--)if(targets.get(i).bounds.contains(x,y)){touchTarget=i;focus=i;if("APPS".equals(screen)&&"APP".equals(targets.get(i).kind))handler.postDelayed(touchLongPress,650);invalidate();break;}return true;}
            if(e.getAction()==MotionEvent.ACTION_MOVE&&touchTarget>=0){if(Math.abs(x-touchX)+Math.abs(y-touchY)>35){handler.removeCallbacks(touchLongPress);if("APPS".equals(screen)&&"APP".equals(targets.get(touchTarget).kind))dragging=true;}if(dragging){drawTrash=true;dragX=x;dragY=y;invalidate();}return true;}
            if(e.getAction()==MotionEvent.ACTION_UP){handler.removeCallbacks(touchLongPress);boolean moved=dragging;dragging=false;drawTrash=false;if(moved){if(y>570&&touchTarget>=0&&touchTarget<targets.size())confirmUninstall(targets.get(touchTarget).app);invalidate();return true;}if(longPressFired)return true;if(touchTarget>=0&&touchTarget<targets.size())activate(targets.get(touchTarget));invalidate();return true;}
            if(e.getAction()==MotionEvent.ACTION_CANCEL){handler.removeCallbacks(touchLongPress);dragging=false;drawTrash=false;invalidate();}
            return true;
        }

        @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
            if (keyCode == KeyEvent.KEYCODE_BACK) { goHome(); return true; }
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER || keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                if(!event.isLongPress()){heldKey=keyCode;handler.removeCallbacks(keyLongPress);handler.postDelayed(keyLongPress,750);}
                if(event.getRepeatCount()==0){longPressFired=false;heldKey=keyCode;handler.removeCallbacks(keyLongPress);handler.postDelayed(keyLongPress,750);}
                return true;
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT || keyCode == KeyEvent.KEYCODE_DPAD_UP || keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                moveFocus(keyCode); return true;
            }
            if (keyCode == KeyEvent.KEYCODE_PAGE_DOWN && "APPS".equals(screen)) { changePage(1); return true; }
            if (keyCode == KeyEvent.KEYCODE_PAGE_UP && "APPS".equals(screen)) { changePage(-1); return true; }
            return super.onKeyDown(keyCode, event);
        }
        @Override public boolean onKeyUp(int keyCode,KeyEvent event){if(keyCode==KeyEvent.KEYCODE_DPAD_CENTER||keyCode==KeyEvent.KEYCODE_ENTER||keyCode==KeyEvent.KEYCODE_NUMPAD_ENTER){handler.removeCallbacks(keyLongPress);heldKey=-1;if(!longPressFired&&focus>=0&&focus<targets.size())activate(targets.get(focus));return true;}return super.onKeyUp(keyCode,event);}

        private void moveFocus(int direction) {
            if (targets.isEmpty()) return;
            if (focus < 0 || focus >= targets.size()) focus = 0;
            RectF from = targets.get(focus).bounds;
            float fx = from.centerX(), fy = from.centerY();
            int best = -1; double bestScore = Double.MAX_VALUE;
            for (int i=0;i<targets.size();i++) {
                if (i==focus) continue;
                RectF r=targets.get(i).bounds; float dx=r.centerX()-fx,dy=r.centerY()-fy;
                float primary, cross;
                if(direction==KeyEvent.KEYCODE_DPAD_LEFT){if(dx>=-1)continue;primary=-dx;cross=Math.abs(dy);}
                else if(direction==KeyEvent.KEYCODE_DPAD_RIGHT){if(dx<=1)continue;primary=dx;cross=Math.abs(dy);}
                else if(direction==KeyEvent.KEYCODE_DPAD_UP){if(dy>=-1)continue;primary=-dy;cross=Math.abs(dx);}
                else {if(dy<=1)continue;primary=dy;cross=Math.abs(dx);}
                double score=primary+cross*1.45;
                if(score<bestScore){bestScore=score;best=i;}
            }
            if(best>=0){focus=best;invalidate();return;}
            if("APPS".equals(screen) && direction==KeyEvent.KEYCODE_DPAD_DOWN && (page+1)*12<getVisibleApps().size()) changePage(1);
            else if("APPS".equals(screen) && direction==KeyEvent.KEYCODE_DPAD_UP && page>0) changePage(-1);
        }

        private void changePage(int delta) {
            List<AppItem> visible=getVisibleApps();
            int max=Math.max(0,(visible.size()-1)/12);
            int next=Math.max(0,Math.min(max,page+delta));
            if(next==page)return;
            page=next; focus=0; invalidate();
        }

        private void activate(Target t) {
            if ("APP".equals(t.kind) && t.app != null) { launch(t.app); return; }
            if ("PINAPP".equals(t.kind) && t.app != null) { if(!pinnedPackages.remove(t.app.packageName))pinnedPackages.add(t.app.packageName);savePins();rebuildFavorites();invalidate();return; }
            if ("PINBACK".equals(t.kind)) { goHome();return; }
            if ("THEME".equals(t.kind)) { darkMode=!darkMode;getContext().getSharedPreferences("launcher",MODE_PRIVATE).edit().putBoolean("dark",darkMode).apply();invalidate();return; }
            if ("PINMODE".equals(t.kind)) { screen="PIN";section=2;page=0;focus=8;invalidate();return; }
            if ("APPS".equals(t.kind)) { setSection(2); return; }
            if ("UTILITY".equals(t.kind)) {
                if ("memory".equals(t.label)) cleanBackgroundApps();
                else if ("speed".equals(t.label)) openStorageSettings();
                else if ("folder".equals(t.label)) openFiles();
                else if ("gear".equals(t.label)) openSettings();
                return;
            }
            if ("NAV".equals(t.kind)) {
                if ("home".equals(t.label)) { goHome(); }
                else if ("search".equals(t.label)) openSearch();
                else if ("apps".equals(t.label)) setSection(2);
                else if ("movies".equals(t.label)) setSection(3);
                else if ("tv".equals(t.label)) setSection(4);
                else if ("settings".equals(t.label)) openSettings();
                else if ("power".equals(t.label)) Toast.makeText(HomeActivity.this, "Desligue pela tecla Power do controle ou da TV.", Toast.LENGTH_LONG).show();
            }
        }

        private void launch(AppItem app) {
            try {
                Intent i = new Intent(app.launchIntent);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Exception ex) {
                Toast.makeText(HomeActivity.this, "Não foi possível abrir " + app.label, Toast.LENGTH_SHORT).show();
            }
        }

        private void setSection(int value) {
            section=value; page=0; screen=value==0?"HOME":"APPS"; focus=value==0?13:7; invalidate();
        }

        void goHome() { section=0; screen="HOME"; page=0; focus=13; searchQuery=""; invalidate(); }

        private void savePins(){getContext().getSharedPreferences("launcher",MODE_PRIVATE).edit().putStringSet("pinned",new HashSet<String>(pinnedPackages)).apply();}
        private void rebuildFavorites(){favorites.clear();String[] order={"com.google.android.youtube.tv","com.netflix.mediaclient","com.amazon.avod.thirdpartyclient","com.disney.disneyplus","br.com.globo.play","com.globo.globotv","com.spotify.tv.android","com.spotify.music","com.android.vending","com.example.playback4mitv","com.newvod.app","com.liveb2.app","com.smalls.xplussports"};for(String p:order){AppItem a=byPackage.get(p);if(a!=null&&pinnedPackages.contains(p))favorites.add(a);}}
        private void confirmUninstall(final AppItem app){if(app==null)return;new AlertDialog.Builder(HomeActivity.this).setTitle("Desinstalar aplicativo?").setMessage("Deseja desinstalar "+app.label+"?").setNegativeButton("Cancelar",null).setPositiveButton("Desinstalar",new DialogInterface.OnClickListener(){@Override public void onClick(DialogInterface d,int w){try{Intent i=new Intent(Intent.ACTION_UNINSTALL_PACKAGE,Uri.parse("package:"+app.packageName));i.putExtra(Intent.EXTRA_RETURN_RESULT,true);startActivityForResult(i,41);}catch(Exception e){Toast.makeText(HomeActivity.this,"O Android não permitiu desinstalar este aplicativo",Toast.LENGTH_LONG).show();}}}).show();}
        void refreshApps(){byPackage.clear();apps.clear();favorites.clear();loadApps();rebuildFavorites();invalidate();}

        private void openSearch() {
            final EditText input = new EditText(HomeActivity.this);
            input.setSingleLine(true);
            input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
            input.setHint("Digite o nome do aplicativo");
            new AlertDialog.Builder(HomeActivity.this)
                    .setTitle("Buscar aplicativos")
                    .setView(input)
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Buscar", new DialogInterface.OnClickListener() {
                        @Override public void onClick(DialogInterface dialog, int which) {
                            searchQuery = input.getText().toString().trim();
                            section = 1; screen = "APPS"; page = 0; focus = 7; invalidate();
                        }
                    }).show();
            input.requestFocus();
            input.postDelayed(new Runnable() {
                @Override public void run() {
                    InputMethodManager imm = (InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);
                    if (imm != null) imm.showSoftInput(input, InputMethodManager.SHOW_IMPLICIT);
                }
            }, 250L);
        }

        private void openStorageSettings() {
            try {
                Intent storage = new Intent("android.settings.INTERNAL_STORAGE_SETTINGS");
                if (storage.resolveActivity(getPackageManager()) != null) startActivity(storage);
                else openSettings();
            } catch (Exception ex) { openSettings(); }
        }

        private void openSettings() {
            try { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
            catch (Exception ex) { Toast.makeText(HomeActivity.this,"Configurações indisponíveis",Toast.LENGTH_SHORT).show(); }
        }

        private void openFiles() {
            try {
                Intent launch=getPackageManager().getLaunchIntentForPackage("com.softwinner.TvdFileManager");
                if(launch==null) launch=new Intent(Intent.ACTION_OPEN_DOCUMENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE);
                startActivity(launch);
            } catch(Exception ex) { Toast.makeText(HomeActivity.this,"Gerenciador de arquivos indisponível",Toast.LENGTH_SHORT).show(); }
        }

        private void cleanBackgroundApps() {
            ActivityManager manager=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
            if(manager==null){Toast.makeText(HomeActivity.this,"Não foi possível consultar a memória",Toast.LENGTH_SHORT).show();return;}
            List<ActivityManager.RunningAppProcessInfo> running=manager.getRunningAppProcesses();
            Set<String> killed=new HashSet<String>();
            if(running!=null) for(ActivityManager.RunningAppProcessInfo process:running){
                if(process==null||process.pkgList==null||process.importance<ActivityManager.RunningAppProcessInfo.IMPORTANCE_BACKGROUND)continue;
                for(String pkg:process.pkgList){
                    if(pkg==null||pkg.equals(getPackageName())||pkg.startsWith("android.")||pkg.startsWith("com.android.")||pkg.startsWith("com.google.android.")||pkg.startsWith("com.google.")||pkg.startsWith("com.olive."))continue;
                    try{
                        ApplicationInfo info=getPackageManager().getApplicationInfo(pkg,0);
                        if((info.flags&ApplicationInfo.FLAG_SYSTEM)==0 && killed.add(pkg)) manager.killBackgroundProcesses(pkg);
                    }catch(PackageManager.NameNotFoundException ignored){}
                }
            }
            ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); manager.getMemoryInfo(mi);
            long mib=mi.availMem/(1024L*1024L);
            Toast.makeText(HomeActivity.this,"Limpeza concluída • " + killed.size() + " apps em segundo plano • " + mib + " MB livres",Toast.LENGTH_LONG).show();
        }
    }
}
