# XPLUS Home Leve

Launcher Android nativo para o XPLUS (Android 7.1.2 / API 25). A tela é desenhada em Canvas; o APK não usa WebView, rede, banco local, imagens externas ou serviços em segundo plano.

## Compilar

No computador deste projeto:

```powershell
powershell -ExecutionPolicy Bypass -File .\custom_launcher\build.ps1
```

O APK compilado sai em `custom_launcher\XPLUS-Home-Leve.apk` e é copiado para `backups\launcher-new\XPLUS-Home-Leve.apk`. O script usa `ANDROID_SDK_ROOT` ou o SDK em `%LOCALAPPDATA%\Android\Sdk`. A keystore de assinatura não foi incluída. Mantenha essa chave para atualizar a instalação já assinada; se ela for perdida, desinstale o launcher antes de instalar uma compilação assinada com outra chave.

## Conteúdo

- Tela inicial em azul-marinho, barra lateral e atalhos de limpeza/configurações. O botão superior alterna entre os temas azul-marinho escuro e azul; nenhum deles usa fundo branco. A fileira principal mostra apenas os apps fixados que estão instalados e habilitados.
- Navegação por mouse e teclas direcionais/Enter/Voltar.
- Botão “Fixar apps” na tela inicial; a tela de seleção guarda os atalhos escolhidos entre reinicializações.
- Gaveta de apps, busca com teclado Android e filtros de filmes e TV. A gaveta lista apps instalados e habilitados, inclusive os que ainda não foram abertos depois de um boot; esconde pacotes desativados e utilitários internos de atualização.
- Na gaveta, toque longo ou OK segurado abre a confirmação de desinstalação do launcher; arrastar um app para a área inferior também pede confirmação. A tela de confirmação do Android ainda exige uma segunda confirmação para remover o pacote.
- O atalho “YouTube” abre diretamente o app oficial `com.google.android.youtube.tv`. No firmware atual, esse app ainda exibe a mensagem oficial “Este dispositivo não é compatível com o YouTube”; não foi substituído por outro cliente. O pacote oficial permanece instalado.
- O receptor de instalação automática `realplay.com.timeserver/.install.installApkReceiver` foi desativado para impedir que apps removidos sejam reinstalados pelo instalador OEM. O serviço TimeServer permanece ativo para as demais funções.
- Limpeza de processos de apps de usuário em segundo plano; Configurações e gerenciador de arquivos abrem os apps do sistema.
- Não mostra atalhos para pacotes desativados ou ausentes.

## Restaurar launchers

O APK atualizado original, o APK OEM do firmware, o dump do pacote e os hashes ficam em `backups\launcher-original`. O APK atualizado foi removido do armazenamento de dados. O original OEM foi removido para o usuário 0, mas permanece dentro de `/system/app` no firmware; ele não foi apagado manualmente para evitar risco ao boot. O backup bruto do eMMC anterior às alterações está em `backups\android-full\mmcblk0-full.img`. Para reinstalar o APK atualizado pelo ADB:

```powershell
adb install -r .\backups\launcher-original\com.xbs.xplus-base.apk
adb shell cmd package set-home-activity --user 0 com.xbs.xplus/com.xbs.xplus_v3.MainActivity
```

Para restaurar somente a cópia OEM do firmware para o usuário 0:

```powershell
adb shell cmd package install-existing --user 0 com.xbs.xplus
adb shell pm enable --user 0 com.xbs.xplus
adb shell cmd package set-home-activity --user 0 com.xbs.xplus/.MainActivity
```

Para reativar o novo launcher como padrão:

```powershell
adb install -r .\backups\launcher-new\XPLUS-Home-Leve.apk
adb shell cmd package set-home-activity --user 0 com.olive.xpluslauncher/.HomeActivity
```

Os APKs originais são cópias instaláveis, mas não incluem dados privados/configurações que o app guardava no aparelho. A chave local do novo launcher está em `custom_launcher\build\xplus-home-debug.keystore`.



