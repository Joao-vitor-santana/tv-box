$ErrorActionPreference = 'Stop'

$Project = Split-Path -Parent $MyInvocation.MyCommand.Path
$Sdk = if ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } elseif ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'Android\Sdk' } else { throw 'Defina ANDROID_SDK_ROOT para compilar.' }
$Platform = Join-Path $Sdk 'platforms\android-34\android.jar'
$Tools = Join-Path $Sdk 'build-tools\36.0.0'
$Aapt2 = Join-Path $Tools 'aapt2.exe'
$D8 = Join-Path $Tools 'd8.bat'
$Zipalign = Join-Path $Tools 'zipalign.exe'
$ApkSigner = Join-Path $Tools 'apksigner.bat'
$Javac = (Get-Command javac.exe).Source
$Jar = Join-Path (Split-Path $Javac) 'jar.exe'
$Keytool = Join-Path (Split-Path $Javac) 'keytool.exe'
$Out = Join-Path $Project 'build'
$Source = Join-Path $Project 'src\main\java\com\olive\xpluslauncher\HomeActivity.java'
$Manifest = Join-Path $Project 'src\main\AndroidManifest.xml'
$Resources = Join-Path $Project 'src\main\res'
$CompiledResources = Join-Path $Out 'resources.zip'
$Generated = Join-Path $Out 'generated'
$Classes = Join-Path $Out 'classes'
$Dex = Join-Path $Out 'dex'
$Keystore = Join-Path $Out 'xplus-home-debug.keystore'
$Unsigned = Join-Path $Out 'unsigned.apk'
$Aligned = Join-Path $Out 'aligned.apk'
$Apk = Join-Path $Project 'XPLUS-Home-Leve.apk'

foreach ($Required in @($Platform, $Aapt2, $D8, $Zipalign, $ApkSigner, $Source, $Manifest)) {
    if (-not (Test-Path -LiteralPath $Required)) { throw "Arquivo necessário não encontrado: $Required" }
}

New-Item -ItemType Directory -Force -Path $Out, $Classes, $Dex, $Generated | Out-Null
Get-ChildItem -LiteralPath $Classes -Force | Remove-Item -Recurse -Force
Get-ChildItem -LiteralPath $Dex -Force | Remove-Item -Recurse -Force
Get-ChildItem -LiteralPath $Generated -Force | Remove-Item -Recurse -Force
Remove-Item -LiteralPath $CompiledResources, $Unsigned, $Aligned, $Apk -Force -ErrorAction SilentlyContinue

& $Aapt2 compile --dir $Resources -o $CompiledResources
if ($LASTEXITCODE -ne 0) { throw 'aapt2 compile falhou' }
& $Aapt2 link --manifest $Manifest -I $Platform -R $CompiledResources --java $Generated --auto-add-overlay --min-sdk-version 23 --target-sdk-version 25 --version-code 1 --version-name 1.0 -o $Unsigned
if ($LASTEXITCODE -ne 0) { throw 'aapt2 link falhou' }

& $Javac -encoding UTF-8 -source 1.8 -target 1.8 -bootclasspath $Platform -d $Classes $Source
if ($LASTEXITCODE -ne 0) { throw 'javac falhou' }

$ClassFiles = @(Get-ChildItem -LiteralPath $Classes -Recurse -Filter '*.class' | ForEach-Object { $_.FullName })
if ($ClassFiles.Count -eq 0) { throw 'Nenhum arquivo .class foi compilado' }
& $D8 --lib $Platform --min-api 23 --output $Dex $ClassFiles
if ($LASTEXITCODE -ne 0) { throw 'd8 falhou' }

Push-Location $Dex
try { & $Jar uf $Unsigned classes.dex; if ($LASTEXITCODE -ne 0) { throw 'inclusão de classes.dex falhou' } }
finally { Pop-Location }

& $Zipalign -f 4 $Unsigned $Aligned
if ($LASTEXITCODE -ne 0) { throw 'zipalign falhou' }

if (-not (Test-Path -LiteralPath $Keystore)) {
    & $Keytool -genkeypair -keystore $Keystore -storepass android -keypass android -alias xplus-home -dname 'CN=XPLUS Home Leve, OU=Local, O=TVBox, C=BR' -keyalg RSA -keysize 2048 -validity 10000
    if ($LASTEXITCODE -ne 0) { throw 'keytool falhou' }
}

& $ApkSigner sign --ks $Keystore --ks-key-alias xplus-home --ks-pass pass:android --key-pass pass:android --out $Apk $Aligned
if ($LASTEXITCODE -ne 0) { throw 'apksigner sign falhou' }
& $ApkSigner verify --verbose $Apk
if ($LASTEXITCODE -ne 0) { throw 'verificação de assinatura falhou' }

$Backup = Join-Path $Project '..\backups\launcher-new\XPLUS-Home-Leve.apk'
Copy-Item -LiteralPath $Apk -Destination $Backup -Force
Write-Output "APK criado: $Apk"
Write-Output "Backup do APK: $Backup"

