# Histórico do chat e execução

Resumo cronológico para continuidade por outra IA. Endereços de rede e caminhos pessoais foram omitidos.

## Pedidos e decisões

1. O usuário pediu otimização do XPLUS via ADB, remoção de anúncios/apps desnecessários, medição de RAM, armazenamento e CPU/GPU, e redução de processos em segundo plano.
2. Pediu uma interface própria baseada em imagens de referência, substituição do launcher original e backups dos dois launchers. Corrigiu a identificação das capturas: a tela com menos apps era o launcher em uso.
3. Pediu interface azul sem fundo branco, modo escuro/normal, fixar apps na Home, busca, todos os apps e desinstalação por toque longo/OK segurado/arrastar para lixeira.
4. Pediu que o YouTube original funcionasse, rejeitando um cliente alternativo.
5. Relatou que apps desinstalados voltavam após algum tempo.
6. Pediu backup completo do Android e orientação sobre qual imagem modificar e como reinstalar.
7. Pediu publicar o trabalho no GitHub para outra IA continuar.

## Alterações e medições registradas

- Desenvolvido launcher nativo Android em `custom_launcher/src`; não usa WebView, rede ou serviço contínuo.
- Launcher definido como HOME: `com.olive.xpluslauncher/.HomeActivity`.
- APK atual do launcher: 29.156 bytes. Código e APK neste pacote.
- Medição comparativa documentada em `performance-comparison.txt`: processo do launcher original tinha PSS 50.238 KB; novo launcher, em medição anterior, 27.399 KB (redução observada de ~45%). RAM disponível subiu de 507.916 KB para 544.244 KB (+36.328 KB); espaço livre em `/data` subiu de 1.418.616 KB para 1.788.128 KB (+369.512 KB), incluindo limpeza de caches/dados. Amostras de CPU posteriores não foram comparáveis. Frequência reportada de GPU foi 600 MHz, sem telemetria de utilização; portanto não há ganho percentual confiável de GPU.
- Backup bruto do eMMC concluído antes das modificações: 7.818.182.656 bytes; SHA-256 em `backup-sha256.txt`. Boot areas e extração original da partição `super` também estão no backup local, não neste pacote.
- A partição `super` original tem 2 GiB e contém partições dinâmicas Android `system`, `vendor` e `product`. É mais apropriada para estudar/modificar o firmware; a imagem integral fica preservada como recuperação.

## Reinstalação automática de apps

- `com.newvod.app`, `com.example.playback4mitv` e atualização do launcher OEM foram associados ao instalador `realplay.com.timeserver`.
- Pacote instalado em `/system/priv-app/TimeServer/TimeServer.apk`; componente `realplay.com.timeserver/.install.installApkReceiver` identificado na inspeção do dex como receptor de APKs.
- Apenas esse componente foi desativado para user 0 usando Package Manager. A saída final mostrou `disabledComponents` com o receptor. Serviço TimeServer preservado.
- SmartTube foi removido do aparelho. O tile YouTube chama o app original.

## YouTube original — pendente

- App presente: `com.google.android.youtube.tv`, APK OEM `YouTubeLeanback.apk`, versão 2.14.133.
- Inicialmente o firmware não anunciava `android.software.leanback`, embora declare dispositivo TV. Foi adicionada uma configuração XML de feature por overlay; após reiniciar, `pm list features` continuou sem Leanback.
- Teste real em tela confirmou a mensagem: “Este dispositivo não é compatível com o YouTube”. Portanto, não alegar que foi corrigido. Não foi feita alteração de fingerprint/modelo porque isso pode afetar certificação e outros serviços.
- Em etapa anterior, `pm clear com.google.android.youtube.tv` foi executado embora a tentativa de backup dos dados do app tivesse falhado. Sessão/configurações locais podem ter sido apagadas; pode ser necessário login. A imagem integral atual foi capturada depois desse clear, então não recupera esses dados anteriores.

## Segurança e limite dos backups

- Imagem integral bruta contém Android, dados do usuário e configuração do dispositivo; não foi incluída neste pacote público/compartilhável.
- A área protegida RPMB não foi lida.
- `mmcblk0.img` é uma captura parcial antiga, não usar para restauração.
- Não gravar imagens por ADB enquanto Android está executando. Qualquer flash deve ser validado para o modelo e mecanismo de recovery/burning exatos.
